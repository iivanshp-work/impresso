/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'id', {
	clear: 'Hapus',
	highlight: 'Sorot',
	options: 'Pilihan Warna',
	selected: 'Warna Dipilih',
	title: 'Pilih Warna'
} );
